from items.item import Item


class Branch(Item):
    def __init__(self):
        super().__init__('konar', 'Mocný konár visiaci zo stropu nad priepasťou. Hrubý a pevný.')
