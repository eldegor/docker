# python-textovka
introduction to python by creating the text based adventure game (interactive fiction)
